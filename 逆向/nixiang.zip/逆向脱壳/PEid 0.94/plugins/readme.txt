[ The FSG v1.33 Unpacker plugin coded by _pusher_ ]

This plugin unpacks FSG v1.33 only, i've waited long for a such plugin like this
and now.. we finally got ONE.. hopefully there will be more.
Iam glad snaker gave me the opportunity to be the first one to be coding the
first unpacker plugin, I added a sample source in delphi on howto make more plugins.


[ Thanks ]

I would like to thank [-SMoKE-] for the fsg unpacker source
and snaker for showing me how to write a plugin for your PEiD


[ Bugs ]

yup, the IAT Rebuilding didt seem to work.
in the future i'll try to fix theese things.


//_pusher_